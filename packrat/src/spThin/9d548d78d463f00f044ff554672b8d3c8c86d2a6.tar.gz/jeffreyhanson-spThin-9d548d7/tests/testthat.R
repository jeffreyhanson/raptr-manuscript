library(testthat)
library(spThin)

test_check("spThin")
