# spThin 1.0.0

* Heuristic thinning algorithm implemented in c++.

* Functions to rarefy occurrence records.

* Exact-algorithm thinning methods implemented using lp_solve and Gurobi.

* Plots generated using ggplot2.

* Formal SpRarefy and SpThin classes defined using S4.

* S3 methods for SpRarefy and SpThin classes.

# spThin 0.10

* Initial package
