# structurer 1.1.1
* fixed bugs relating to ADMBURNIN in traceplots and R statistics

# structurer 1.1.0

* Added functionality to check convergence of Structure runs
+ added methods to make traceplots of MCMC runs
+ added methods to calculate Gelman-Rubin statistics

# structurer 1.0.0

* Basic functionality

# structurer 0.0.1

* Initial package commit
