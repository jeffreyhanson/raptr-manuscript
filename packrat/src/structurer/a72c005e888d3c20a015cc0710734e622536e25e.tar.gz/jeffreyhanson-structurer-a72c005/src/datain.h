#include "structure.h"

void ReadInputFile (int *Geno, double *Mapdistances, char *Markernames, struct IND *Individual,double *Phase,int *Recessive);
void CountAlleles (int *Geno, int *NumAlleles, int *Translation, int *Recessive);
