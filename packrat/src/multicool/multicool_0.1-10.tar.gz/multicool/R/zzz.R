# .onLoad <- function(libname, pkgname) {
#   loadRcppModules()
# }

loadModule("Multicool", TRUE)
