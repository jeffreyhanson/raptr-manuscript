example_fstat_aflp.dat
========================

This data file contains data for _Androsace_obtusifolia_. It was obtained from [Meirmans _et al. (2011)](http://datadryad.org/resource/doi:10.5061/dryad.f3rk4).

It is purely used as an example. If you have a better binary AFLP FTSTAT file you are willing to share, please email me at jeffrey.hanson@uqconnect.edu.au.

[Meirmans P.G., Goudet J., IntraBioDiv Consortium, & Gaggiotti O.E. (2011). Ecology and life history affect different aspects of the population structure of 27 high-alpine plants. Molecular Ecology 20: 3144-3155.](http://dx.doi.org/10.1111/j.1365-294X.2011.05164.x)
