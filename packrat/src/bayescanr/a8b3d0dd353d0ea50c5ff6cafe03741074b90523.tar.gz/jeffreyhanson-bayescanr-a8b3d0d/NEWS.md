# bayescanr 1.0.1
* fixed bug where files for multiple replicates would overwrite each other
* added funcionality to produce traceplots and calculate Gelman-Rubin statistics using coda

# bayescanr 1.0.0

* Basic functionality

# bayescanr 0.0.1

* Initial package commit
