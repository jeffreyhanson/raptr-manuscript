#' @include dependencies.R bayescanr-internal.R
NULL
