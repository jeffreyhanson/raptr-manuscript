library(testthat)
library(bayescanr)
test_check("bayescanr")

