library("testthat")
library("lazyWeave")

test_check("lazyWeave")