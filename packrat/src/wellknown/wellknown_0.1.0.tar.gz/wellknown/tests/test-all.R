library('testthat')
library('wellknown')

test_check('wellknown')
