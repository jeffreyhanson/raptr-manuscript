#ifndef CUBICSOLVER_H
#define CUBICSOLVER_H
int cubicsolver(double a, double b, double c, double d, double roots[][2]);
#endif // CUBICSOLVER

